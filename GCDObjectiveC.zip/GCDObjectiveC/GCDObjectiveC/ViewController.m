//
//  ViewController.m
//  GCDObjectiveC
//
//  Created by cricket21 on 07/08/17.
//  Copyright © 2017 cricket21. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(UIImage*)Downloadimage:(NSString*)strUrl{
    NSData * imageData = [[NSData alloc] initWithContentsOfURL: [NSURL URLWithString:strUrl]];
    UIImage *img = [UIImage imageWithData:imageData];
    return img;
}



- (IBAction)SerialDispatchQueues:(id)sender {
    dispatch_queue_t serialQueue = dispatch_queue_create("com.blah.queue", DISPATCH_QUEUE_SERIAL);
    
    dispatch_async(serialQueue, ^{
        //block1
         UIImage *img  =[self Downloadimage:@"https://media1.britannica.com/eb-media/20/155820-131-7921972A.jpg"];
        dispatch_async(dispatch_get_main_queue(),^{
            self.Img1.image=img;
        });
    });
    
    dispatch_async(serialQueue, ^{
         UIImage *img  =[self Downloadimage:@"https://www.w3schools.com/css/img_mountains.jpg"];
        dispatch_async(dispatch_get_main_queue(),^{
         self.Img2.image=img;
        });
        
    });
    
    dispatch_async(serialQueue, ^{
         UIImage *img  =[self Downloadimage:@"http://keenthemes.com/preview/metronic/theme/assets/global/plugins/jcrop/demos/demo_files/image2.jpg"];
        dispatch_async(dispatch_get_main_queue(),^{
            self.Img3.image=img;
        });
        
    });
    
    dispatch_async(serialQueue, ^{
        UIImage *img  =[self Downloadimage:@"https://www.smashingmagazine.com/wp-content/uploads/2016/01/07-responsive-image-example-castle-7-opt.jpg"];
        dispatch_async(dispatch_get_main_queue(),^{
            self.Img4.image=img;
        });
        
    });
    
    dispatch_async(serialQueue, ^{
        UIImage *img  =[self Downloadimage:@"https://www.smashingmagazine.com/wp-content/uploads/2016/01/07-responsive-image-example-castle-7-opt.jpg"];
        dispatch_async(dispatch_get_main_queue(),^{
            self.Img1.image=img;
        });
        
    });
    
    
}


- (IBAction)ConcurrentDispatchQueues:(id)sender {
    
    dispatch_async(dispatch_get_global_queue( DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        UIImage *img  =[self Downloadimage:@"https://www.w3schools.com/css/img_mountains.jpg"];
        dispatch_async(dispatch_get_main_queue(), ^{
            self.Img1.image=img;
        });
    });
    
    dispatch_async(dispatch_get_global_queue( DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        UIImage *img  =[self Downloadimage:@"https://media1.britannica.com/eb-media/20/155820-131-7921972A.jpg"];
        dispatch_async(dispatch_get_main_queue(), ^{
            self.Img2.image=img;
        });
    });
    
    dispatch_async(dispatch_get_global_queue( DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        UIImage *img  =[self Downloadimage:@"https://www.smashingmagazine.com/wp-content/uploads/2016/01/07-responsive-image-example-castle-7-opt.jpg"];
        dispatch_async(dispatch_get_main_queue(), ^{
            self.Img3.image=img;
        });
    });
    
    dispatch_async(dispatch_get_global_queue( DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        UIImage *img  =[self Downloadimage:@"http://keenthemes.com/preview/metronic/theme/assets/global/plugins/jcrop/demos/demo_files/image2.jpg"];
        dispatch_async(dispatch_get_main_queue(), ^{
            self.Img4.image=img;
        });
    });
}
@end
