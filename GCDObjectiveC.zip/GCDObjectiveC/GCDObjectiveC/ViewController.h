//
//  ViewController.h
//  GCDObjectiveC
//
//  Created by cricket21 on 07/08/17.
//  Copyright © 2017 cricket21. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
- (IBAction)ConcurrentDispatchQueues:(id)sender;
@property (strong, nonatomic) IBOutlet UIImageView *Img1;
@property (strong, nonatomic) IBOutlet UIImageView *Img2;
@property (strong, nonatomic) IBOutlet UIImageView *Img3;
@property (strong, nonatomic) IBOutlet UIImageView *Img4;
@end

